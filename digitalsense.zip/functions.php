<?php
// header stylesheet and mdb

function digitalsense_register_styles(){

    wp_enqueue_style('digitalsense-style', get_template_directory_uri() . "/style.css", array(), '1.0', 'all');
    wp_enqueue_style('digitalsense-bootstrap', "https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.3.0/mdb.min.css", array(), '3.3.0', 'all');
} 
add_action('wp_enqueue_scripts', 'digitalsense_register_styles')
?>

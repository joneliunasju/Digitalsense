<!DOCTYPE HTML>
<html>
	<head>
	<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
  <meta http-equiv="x-ua-compatible" content="ie=edge" />
  <title>Digitalsense</title>
<!-- Google Fonts -->
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600&display=swap" rel="stylesheet">
<!-- swiper style  -->
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.css" />
<link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
<?php
wp_head();
?>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
</head>
<body>
 <div style="--swiper-navigation-color: #fff; --swiper-pagination-color: #fff"
    class="swiper-container mySwiper">
    <div class="parallax-bg";
      data-swiper-parallax="-23%"
    ></div>
    <div class="swiper-wrapper">
      <div class="swiper-slide">
          <div class="row">
          <div class="kaire col-md-7 col-sm-12">  
              <div class="title" data-swiper-parallax="-300">01</div>
          <div class="subtitle" data-swiper-parallax="-200"><?php if ( $pavadinimas = get_field( 'pavadinimas' ) ) : ?>
	<?php echo esc_html( $pavadinimas ); ?>
<?php endif; ?></div>
          <div class="text" data-swiper-parallax="-100">
            <p><?php if ( $tekstas = get_field( 'tekstas' ) ) : ?>
	<?php echo esc_html( $tekstas ); ?>
<?php endif; ?>
            </p></div></div>
       <div class="desine col-md-5 col-sm-12">
           <div class="nuotrauka d-flex justify-content-end">
           <?php
$nuotrauka = get_field( 'nuotrauka' );
if ( $nuotrauka ) : ?>
	<img src="<?php echo esc_url( $nuotrauka['url'] ); ?>" alt="<?php echo esc_attr( $nuotrauka['alt'] );?>" />
<?php endif; ?></div>
       </div>
        </div>
        </div>
        <div class="swiper-slide">
          <div class="row">
          <div class="kaire col-md-7 col-sm-12">  
              <div class="title" data-swiper-parallax="-300">02</div>
          <div class="subtitle" data-swiper-parallax="-200"><?php if ( $pavadinimas2 = get_field( 'pavadinimas2' ) ) : ?>
	<?php echo esc_html( $pavadinimas2 ); ?>
<?php endif; ?></div>
          <div class="text" data-swiper-parallax="-100">
            <p><?php if ( $tekstas2 = get_field( 'tekstas2' ) ) : ?>
	<?php echo esc_html( $tekstas2 ); ?>
<?php endif; ?></p></div></div>
       <div class="desine col-md-5 col-sm-12">
           <div class="nuotrauka d-flex justify-content-end">
           <?php
$nuotrauka2 = get_field( 'nuotrauka2' );
if ( $nuotrauka2 ) : ?>
	<img src="<?php echo esc_url( $nuotrauka2['url'] ); ?>" alt="<?php echo esc_attr( $nuotrauka2['alt'] );?>" />
<?php endif; ?>
           </div>
       </div>
        </div>
        </div>
        <div class="swiper-slide">
          <div class="row">
          <div class="kaire col-md-7 col-sm-12">  
              <div class="title" data-swiper-parallax="-300">03</div>
          <div class="subtitle" data-swiper-parallax="-200"><?php if ( $pavadinimas3 = get_field( 'pavadinimas3' ) ) : ?>
	<?php echo esc_html( $pavadinimas3 ); ?>
<?php endif; ?></div>
          <div class="text" data-swiper-parallax="-100">
            <p><?php if ( $tekstas3 = get_field( 'tekstas3' ) ) : ?>
	<?php echo esc_html( $tekstas3 ); ?>
<?php endif; ?></p></div></div>
       <div class="desine col-md-5 col-sm-12">
           <div class="nuotrauka d-flex justify-content-end">
           <?php
$nuotrauka3 = get_field( 'nuotrauka3' );
if ( $nuotrauka3 ) : ?>
	<img src="<?php echo esc_url( $nuotrauka3['url'] ); ?>" alt="<?php echo esc_attr( $nuotrauka3['alt'] );?>" />
<?php endif; ?>
           </div>
       </div>
        </div>
        </div>
        <div class="swiper-slide">
          <div class="row">
          <div class="kaire col-md-7 col-sm-12">  
              <div class="title" data-swiper-parallax="-300">04</div>
          <div class="subtitle" data-swiper-parallax="-200"><?php if ( $pavadinimas4 = get_field( 'pavadinimas4' ) ) : ?>
	<?php echo esc_html( $pavadinimas4 ); ?>
<?php endif; ?></div>
          <div class="text" data-swiper-parallax="-100">
            <p><?php if ( $tekstas4 = get_field( 'tekstas4' ) ) : ?>
	<?php echo esc_html( $tekstas4 ); ?>
<?php endif; ?></p></div></div>
       <div class="desine col-md-5 col-sm-12">
           <div class="nuotrauka d-flex justify-content-end">
           <?php
$nuotrauka4 = get_field( 'nuotrauka4' );
if ( $nuotrauka4 ) : ?>
	<img src="<?php echo esc_url( $nuotrauka4['url'] ); ?>" alt="<?php echo esc_attr( $nuotrauka4['alt'] );?>" />
<?php endif; ?>
           </div>
       </div>
        </div>
        </div>
        <div class="swiper-slide">
          <div class="row">
          <div class="kaire col-md-7 col-sm-12">  
              <div class="title" data-swiper-parallax="-300">05</div>
          <div class="subtitle" data-swiper-parallax="-200"><?php if ( $pavadinimas5 = get_field( 'pavadinimas5' ) ) : ?>
	<?php echo esc_html( $pavadinimas5 ); ?>
<?php endif; ?></div>
          <div class="text" data-swiper-parallax="-100">
            <p><?php if ( $tekstas5 = get_field( 'tekstas5' ) ) : ?>
	<?php echo esc_html( $tekstas5 ); ?>
<?php endif; ?></p></div></div>
       <div class="desine col-md-5 col-sm-12">
           <div class="nuotrauka d-flex justify-content-end">
           <?php
$nuotrauka5 = get_field( 'nuotrauka5' );
if ( $nuotrauka5 ) : ?>
	<img src="<?php echo esc_url( $nuotrauka5['url'] ); ?>" alt="<?php echo esc_attr( $nuotrauka5['alt'] );?>" />
<?php endif; ?>
           </div>
       </div>
        </div>
        </div></div>
    <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-scrollbar">
      <div class="swiper-scrollbar-drag"><div class="swiper-pagination"><span class="swiper-pagination-current"></span></div>
  </div></div>
</div>
<!-- The social media icon bar -->
<div class="links">
  <div class="icon-bar">
  <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/fb.png" alt="" style="width:9px;"></a>
  <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/insta.png" alt="" style="width:15px;"></a>
  </div>
  <div class="icon-bar-bottom">
  <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/apple.png" alt="" style="width:15px;"></a>
  <a href="#"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/android.png" alt="" style="width:15px;"></a>
    <a href="#" class="get-the-app">GET THE APP</a>
  </div>
</div>
</body>
</html>
<!-- MDB -->
<script
  type="text/javascript"
  src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/3.3.0/mdb.min.js"
></script>
<!-- swiperjs javascriptas -->
<script src="https://unpkg.com/swiper/swiper-bundle.js"></script>
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
<script>
    var swiper = new Swiper('.swiper-container', { 
  pagination: {
    el: '.swiper-pagination',
    type: 'custom',
    renderCustom: function (swiper, current, total) {
      return ('0' + current).slice(-2);
    }
  },
  scrollbar: {
        el: ".swiper-scrollbar",
      },
  navigation: {
    nextEl: '.swiper-button-next',
    prevEl: '.swiper-button-prev',
  },
  direction: 'horizontal',
  slidesPerView: 1,
  spaceBetween: 0,
  mousewheel: true,
    renderCustom: function (swiper, current, total) {
      return current + ' of ' + total;
  }
});
  </script>